def sumatodo(*args):
    return sum(args)